// FASTPATH GENERATED FILE - DO NOT EDIT


/* ACTIONTEXT: Play ListThem*/
_ws.pl = new promptConfig(_ws);
_ws.pl.setID('ID3650_CobasDisambig_listthem_ACTION_1');  //This PlayMsg can be used for Exit Actions or any PlayMsg steps
_ws.pl.addPromptGroup();


_ws.pl.addPromptGroupAudio('messageid', 'ID3650_l_1');  /* When you hear the right Cobas product, say it back to me: Amplicor, Ampliprep, cobas mira, Cobas IT Firewall, integra interface, integra 400 plus, integra 400, integra 700, integra 800, cobas Integra, cobas 4800, cobas p512, cobas p612, c111, c311, c501, c502, c701, c702, c6000, c8000, IT 1000, Omni S, p312, Taqman. (1.5 second pause)  Please say the specific Cobas instrument now. */




// This signifies that this action 'stays here' and doesn't goto a new state
_ws.vm.setReEntry();
